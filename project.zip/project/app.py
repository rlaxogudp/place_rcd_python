from flask import Flask, render_template, request
from datetime import datetime, timedelta
import pandas as pd
import random

app = Flask(__name__)

# CSV 불러오기
df_place = pd.read_csv("combined_places.csv", encoding="utf-8")
df_place.columns = df_place.columns.str.strip()

# 분류 그룹 정의
category_groups = {
    "meal": ["음식점"],
    "play": ["관광명소", "문화생활"],
    "cafe": ["카페"],
    "shop": ["쇼핑"],
    "drink": ["술집"],
    "movie": ["영화"]
}

# 카테고리별 체류 시간 정의
category_durations = {
    "음식점": timedelta(hours=1),
    "술집": timedelta(hours=3),
    "카페": timedelta(hours=2),
    "관광명소": timedelta(hours=1),
    "문화생활": timedelta(hours=1),
    "쇼핑": timedelta(hours=2),
    "영화": timedelta(hours=3)
}

def time_to_half_hour(t: datetime) -> datetime:
    if t.minute == 0:
        return t.replace(second=0, microsecond=0)
    elif t.minute <= 30:
        return t.replace(minute=30, second=0, microsecond=0)
    else:
        return (t.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    region = request.form.get('region')
    male = int(request.form.get('male', 0))
    female = int(request.form.get('female', 0))
    people = male + female
    gender = f"남자 {male}명, 여자 {female}명"
    start_time_str = request.form.get('start_time')

    try:
        current_time = datetime.strptime(start_time_str, "%H:%M")
    except:
        current_time = datetime.strptime("12:00", "%H:%M")

    current_time = time_to_half_hour(current_time)
    start_hour = current_time.hour

    # 지역 필터링
    region_mapping = {
        "강남": "강남구",
        "신촌": "서대문구",
        "홍대": "마포구"
    }
    mapped_address = region_mapping.get(region, None)

    if mapped_address:
        df_pool = df_place[df_place["address_name"].str.contains(mapped_address, na=False)].copy()
    else:
        df_pool = df_place.copy()

    # 시간대별 남은 시간 계산
    time_list = [
        max(0, 12 - start_hour),
        max(0, 18 - max(start_hour, 13)),
        max(0, 24 - max(start_hour, 18)) if start_hour >= 18 else 5
    ]

    # 추천 시퀀스 생성
    sequence_list = []
    hour2 = ["cafe", "shop"]
    hour3 = ["drink"]

    case_hour2 = [["play", "play"], ["cafe"], ["shop"]]
    case_hour3 = [["play", "play", "play"], ["play", random.choice(hour2)], "drink"]
    case_hour4 = [["play"] * 4, ["play", "play", random.choice(hour2)], ["play", random.choice(hour3)]]
    case_hour5 = [
        ["play"] * 5,
        ["play", "play", "play", random.choice(hour2)],
        ["play", "play", random.choice(hour3)],
        ["play", "cafe", "shop"],
        [random.choice(hour2), random.choice(hour3)]
    ]

    for i, t in enumerate(time_list):
        if t == 0 and start_hour not in [12, 18]:
            continue

        if i == 0:  # 오전
            sequence_list.extend(["play"] * t)
        elif i == 1:  # 오후
            if t == 1:
                sequence_list.append("play")
            elif t == 2:
                sequence_list.extend(random.choice(case_hour2))
            elif t >= 3:
                sequence_list.extend(random.choices(hour2 + ["play"], k=t))
        elif i == 2:  # 저녁
            if t == 3:
                c = random.choice(case_hour3)
                sequence_list.extend(c if isinstance(c, list) else [c])
            elif t == 4:
                c = random.choice(case_hour4)
                random.shuffle(c)
                sequence_list.extend(c)
            elif t >= 5:
                c = random.choice(case_hour5)
                random.shuffle(c)
                sequence_list.extend(c)

        if i != 2:
            sequence_list.append("meal")

    # 장소 추천
    schedule = []
    for category_key in sequence_list:
        real_categories = category_groups.get(category_key, [category_key])
        df_candidates = df_pool[df_pool["분류"].isin(real_categories)]

        if df_candidates.empty:
            continue

        place_candidates = df_candidates.sample(n=min(3, len(df_candidates)), replace=False)
        selected = place_candidates.sample(n=1).iloc[0]

        selected_category = selected["분류"]
        duration = category_durations.get(selected_category, timedelta(hours=1))
        if current_time + duration > datetime.strptime("23:59", "%H:%M"):
            break

        schedule.append({
            'time': current_time.strftime('%H:%M'),
            'category': selected_category,
            'candidates': [
                {
                    'place': row.get("place_name"),
                    'category': row.get("분류"),
                    'url': row.get("place_url", "#"),
                    'iframe': row.get("place_url", "#")
                } for _, row in place_candidates.iterrows()
            ]
        })

        current_time += duration
        df_pool = df_pool.drop(index=place_candidates.index)

    return render_template('result.html',
                           region=region,
                           people=people,
                           gender=gender,
                           start_time=start_time_str,
                           schedule=schedule)

if __name__ == '__main__':
    app.run(debug=True)